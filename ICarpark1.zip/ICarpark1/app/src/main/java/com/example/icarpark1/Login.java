package com.example.icarpark1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String PasswordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#&()–[{}]:;',?/*~$^+=<>]).{8,20}$";


    Button btnlogin;
    EditText Email,Password;
    TextView tv;
    TextView tvSignUp;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Email = (EditText) findViewById(R.id.Email);
        Password = (EditText) findViewById(R.id.Password);
        btnlogin = (Button) findViewById(R.id.button);
        tv=(TextView)findViewById(R.id.tv);
        tvSignUp=(TextView)findViewById(R.id.tvSignUp);
        DB = new DBHelper(this);

        tvSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), Register.class);
                startActivity(intent);
            }
        });



        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = Email.getText().toString();
                String password = Password.getText().toString();

                if(Email.length()==0)
                {
                    Email.requestFocus();
                    Email.setError("FIELD CANNOT BE EMPTY");
                }

                else if (!email.matches(EmailPattern) && Email.length() > 0)
                {
                    Email.requestFocus();
                    Email.setError("Invalid email");
                }

                else if(Password.length()==0)
                {
                    Password.requestFocus();
                    Password.setError("FIELD CANNOT BE EMPTY");
                }

                else{
                    Boolean checkuserpass = DB.checkusernamepassword(email, password);
                    if(checkuserpass==true){
                        Toast.makeText(Login.this, "Sign in successful", Toast.LENGTH_SHORT).show();
                        Intent intent  = new Intent(getApplicationContext(), Dashboard.class);
                        String str = StringBuffer.class.toString();
                        intent.putExtra("email", email );
                        startActivity(intent);
                        Email.setText("");
                        Password.setText("");
                    }else{
                        Password.requestFocus();
                        Password.setError("Invalid Credentials");

                    }

                }
            }
        });
    }


}