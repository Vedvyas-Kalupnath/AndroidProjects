package com.example.icarpark1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    EditText FirstName,LastName,Email,Phone,LicenseNumber,Password,Confirm_Password;
    Button signup;
    TextView textView3;

    ProgressDialog progressDialogRegister;

    String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String PasswordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!+%=@#&()–[{}]:;',?/*~$^=<>]).{8,20}$";
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        FirstName=(EditText)findViewById(R.id.FirstName);
        LastName=(EditText)findViewById(R.id.LastName);
        Email=(EditText)findViewById(R.id.Email);
        Phone=(EditText)findViewById(R.id.Phone);
        LicenseNumber=(EditText)findViewById(R.id.LicenseNumber);
        Password=(EditText)findViewById(R.id.Password);
        Confirm_Password=(EditText)findViewById(R.id.Confirm_Password);
        signup = (Button) findViewById(R.id.btnsignup);
        textView3=(TextView)findViewById(R.id.textView3);
        DB = new DBHelper(this);

        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirstName.setText("");
                LastName.setText("");
                Email.setText("");
                Phone.setText("");
                LicenseNumber.setText("");
                Password.setText("");
                Confirm_Password.setText("");
               // finish();
                Intent intent = new Intent(view.getContext(), Login.class);
                startActivity(intent);
            }
        });




        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String firstname = FirstName.getText().toString();
                String lastname = LastName.getText().toString();
                String email = Email.getText().toString();
                String phone = Phone.getText().toString();
                String licensenumber = LicenseNumber.getText().toString();
                String password = Password.getText().toString();
                String confirmpassword = Confirm_Password.getText().toString();


                if(FirstName.length()==0) {
            FirstName.requestFocus();
            FirstName.setError("FIELD CANNOT BE EMPTY");

        }

        else if(LastName.length()==0)
        {
            LastName.requestFocus();
            LastName.setError("FIELD CANNOT BE EMPTY");
        }

        else if(Email.length()==0)
        {
            Email.requestFocus();
            Email.setError("FIELD CANNOT BE EMPTY");
        }

        else if (!email.matches(EmailPattern) && Email.length() > 0)
        {
            Email.requestFocus();
            Email.setError("Invalid email. E.g s@domain.com");
        }

        else if(LicenseNumber.length()==0)
        {
            LicenseNumber.requestFocus();
            LicenseNumber.setError("FIELD CANNOT BE EMPTY");
        }


                else if(Phone.length()==0)
        {
            Phone.requestFocus();
            Phone.setError("FIELD CANNOT BE EMPTY");
        }

        else if (Phone.length()!=8)
        {
            Phone.requestFocus();
            Phone.setError("Invalid Phone Number. Should have 8 numbers ");
        }

        else if(Password.length()==0)
        {
            Password.requestFocus();
            Password.setError("FIELD CANNOT BE EMPTY");

        }

        else if (!password.matches(PasswordPattern) && Password.length() > 0)
        {

            Password.requestFocus();
            Password.setError("Password weak");
        }

        else if(Confirm_Password.length()==0)
        {
            Confirm_Password.requestFocus();
            Confirm_Password.setError("FIELD CANNOT BE EMPTY");

        }


                else{
                    if(password.equals(confirmpassword)){
                        Boolean checkuser = DB.checkusername(email);
                        if(checkuser==false){
                            Boolean insert = DB.insertData(firstname, lastname, email, phone, licensenumber, password);
                            if(insert==true){
                                Toast.makeText(Register.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                FirstName.setText("");
                                LastName.setText("");
                                Email.setText("");
                                Phone.setText("");
                                LicenseNumber.setText("");
                                Password.setText("");
                                Confirm_Password.setText("");

                                Intent intent = new Intent(getApplicationContext(),Dashboard.class);
                                intent.putExtra("email", email);
                                startActivity(intent);
                            }else{
                                Toast.makeText(Register.this, "Registration failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(Register.this, "Email already exists!", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Confirm_Password.requestFocus();
                        Confirm_Password.setError("Password does not match");
                    }
                } }
        });

    }

}