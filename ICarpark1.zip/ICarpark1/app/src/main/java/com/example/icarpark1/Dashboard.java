package com.example.icarpark1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Dashboard extends AppCompatActivity {

    private Button button1, button2, button3, button4, button5, button8;


    TextView tv;
    DBHelper DB;

    String fname,lname,email,phone,licensenumber;
    String n1, n2, n3, n4, n5;
    int lengthfname,lengthlname,lengthemail,lengthphone,lengthlicensenum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        DB = new DBHelper(this);
        email = getIntent().getStringExtra("email");

        button1=findViewById(R.id.button1);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        button5=findViewById(R.id.button5);
        button8=findViewById(R.id.button8);
        tv=(TextView)findViewById(R.id.tv);

        view_Data1(tv);

        button3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openActivityProfile();
            }
        });


//        button5.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                openActivityProfile();
//            }
//        });

    }

    public void view_Data1(View v){
        Cursor res = DB.getdata1(email);
        if(res.getCount()==0){
            Toast.makeText(Dashboard.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuffer buffer = new StringBuffer();
        while(res.moveToNext()){
            buffer.append(res.getString(1));
             fname = buffer.toString();
             lengthfname = fname.length();
            buffer.append(res.getString(2));
             lname = buffer.toString() ;
             lengthlname = lname.length();
            buffer.append(res.getString(3));
             email = buffer.toString() ;
             lengthemail = email.length();
            buffer.append(res.getString(4));
            phone = buffer.toString() ;
            lengthphone = phone.length();
            buffer.append(res.getString(5));
            licensenumber = buffer.toString() ;
            lengthlicensenum = licensenumber.length();

        }

        int sum1 = lengthlname - lengthfname;
        n1 = lname.substring(0,lengthlname-sum1);
        n2 = lname.substring(lengthfname,lengthlname);
        n3 = email.substring(lengthlname,lengthemail);
        n4 = phone.substring(lengthemail,lengthphone);
        n5 = licensenumber.substring(lengthphone,lengthlicensenum);
        tv.setText(n1.substring(0, 1).toUpperCase() + n1.substring(1).toLowerCase() + " " + n2.toUpperCase());
        DB.close();
    }

    private void openActivityProfile() {
        Intent intent = new Intent(this, Profile.class);
        intent.putExtra("fname", n1 );
        intent.putExtra("lname", n2 );
        intent.putExtra("email", n3 );
        intent.putExtra("phone", n4 );
        intent.putExtra("licensenum", n5 );
        startActivity(intent);
    }

    public void view_Data(View v){
        Cursor res = DB.getdata();
        if(res.getCount()==0){
            Toast.makeText(Dashboard.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuffer buffer = new StringBuffer();
        while(res.moveToNext()){

            buffer.append("Question : "+res.getString(1)+"\n");
            buffer.append("Answer : "+res.getString(2)+"\n");
        }

        //alert pop-up for viewing all data
        AlertDialog.Builder builder = new AlertDialog.Builder(Dashboard.this);
        builder.setCancelable(true);
        builder.setTitle("Frequently Asked Questions!");
        builder.setMessage(buffer.toString());
        builder.show();

        DB.close();
    }

    public void logout_process(View view) {

        super.onBackPressed();



    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        //finish();

    }


}