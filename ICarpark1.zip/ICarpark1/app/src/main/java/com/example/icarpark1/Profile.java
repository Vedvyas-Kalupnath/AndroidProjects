package com.example.icarpark1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Profile extends AppCompatActivity {


    TextView tv;
    TextView tv1;

    String n1,n2,n3,n4,n5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        tv=(TextView)findViewById(R.id.tv);
        tv1=(TextView)findViewById(R.id.tv1);

        n1 = getIntent().getStringExtra("fname");
        n2 = getIntent().getStringExtra("lname");
        n3 = getIntent().getStringExtra("email");
        n4 = getIntent().getStringExtra("phone");
        n5 = getIntent().getStringExtra("licensenum");


        tv.setText("First Name : " + n1.substring(0, 1).toUpperCase() + n1.substring(1).toLowerCase() + "\n " + "Last Name : " + "\n" + n2.substring(0, 1).toUpperCase() + n2.substring(1).toLowerCase());
        tv1.setText("Email : " + "\n" + n3 + "\n" + "\n"  + "Phone : " + "\n" + n4 +  "\n" + "\n" + "License Number : " + "\n" + n5);


    }


}